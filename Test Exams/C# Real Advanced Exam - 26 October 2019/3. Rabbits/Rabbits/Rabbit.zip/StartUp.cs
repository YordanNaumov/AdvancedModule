﻿namespace Rabbits
{
    using System;
    public class StartUp
    {
        public static void Main()
        {
            Cage cage = new Cage("Wildness", 20);
            Rabbit rabbit = new Rabbit("Fluffy", "Blanc de Hotot");
            Console.WriteLine(rabbit); //Rabbit (Blanc de Hotot): Fluffy

            //Add Rabbit
            cage.Add(rabbit);
            Console.WriteLine(cage.Count); //1
                                           //Remove Rabbit
            bool a = cage.RemoveRabbit("Rabbit Name"); //false
            Console.WriteLine(a);
            Rabbit secondRabbit = new Rabbit("Bunny", "Brazilian");
            Rabbit thirdRabbit = new Rabbit("Jumpy", "Cashmere Lop");
            Rabbit fourthRabbit = new Rabbit("Puffy", "Cashmere Lop");
            Rabbit fifthRabbit = new Rabbit("Marlin", "Brazilian");

            //Add Rabbits
            cage.Add(secondRabbit);
            cage.Add(thirdRabbit);
            cage.Add(fourthRabbit);
            cage.Add(fifthRabbit);

            //Sell Rabbit by name
            Console.WriteLine(cage.SellRabbit("Bunny")); //Rabbit (Brazilian): Bunny
                                                         
            //Sell Rabbit by species

            Rabbit[] soldSpecies = cage.SellRabbitsBySpecies("Cashmere Lop");

            foreach (var b in soldSpecies)
            {
                Console.WriteLine(b);
            }

            //Console.WriteLine(string.Join(", ", soldSpecies.Select(f => f.Name))); //Jumpy, Puffy

            Console.WriteLine(cage.Report());
            //Rabbits available at Wildness:
            //Rabbit (Blanc de Hotot): Fluffy
            //Rabbit (Brazilian): Marlin

        }
    }
}
